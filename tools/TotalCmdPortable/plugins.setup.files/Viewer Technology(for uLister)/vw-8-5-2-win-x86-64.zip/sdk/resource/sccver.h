#define _FILEFLAGS 0
#define _FILETYPE VFT_DLL
#define _FILESUBTYPE 0
#define S_FILEDESCRIPTION "OIT Localization\000"
#define S_INTERNALNAME "SCCLO\000"
#define S_ORIGINALFILENAME "SCCLO.DLL\000"
#ifndef SLNRC
#define S_COMMENT "Old Build System\000"
#endif
