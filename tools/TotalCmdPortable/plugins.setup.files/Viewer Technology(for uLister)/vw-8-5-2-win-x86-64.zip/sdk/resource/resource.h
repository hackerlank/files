//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by scclo.rc
//
#define IDOK                            1
#define IDCANCEL                        2
#define IDABORT                         3
#define IDRETRY                         4
#define IDIGNORE                        5
#define IDYES                           6
#define IDNO                            7
#define IDCLOSE                         8
#define IDHELP                          9
#define RADIO_HEX2                      308
#define RADIO_HANGUL                    335
#define FI_WINWORD97                    1126
#define FI_MACWORD97                    1133
#define FI_GEM                          1565
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
