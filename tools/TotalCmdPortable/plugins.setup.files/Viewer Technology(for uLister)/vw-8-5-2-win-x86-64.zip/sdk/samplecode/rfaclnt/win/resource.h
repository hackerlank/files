//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RFACLNT.RC
//
#define ID_OPENRFADIAG                  103
#define IDD_SVREDIT                     701
#define IDD_CLNTEDIT                    704
#define IDB_INITOK                      705
#define IDD_FILENAME                    1002
#define IDB_OPENRFAOK                   1003
#define IDB_OPENRFACANCEL               1004
#define IDB_READAHEAD                   40001
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
